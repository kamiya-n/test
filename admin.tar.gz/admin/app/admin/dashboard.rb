ActiveAdmin.register_page "Dashboard" do
  menu priority: 1, label: -> { 'Dashboard' }

  content :title => proc{ "Dashboard" } do

    panel "KPIからのからのお知らせ一覧" do
      table_for [{},{},{},{}].each do
        column "date"
        column "" do |v| raw("テスト") end
      end
    end

  end
end
