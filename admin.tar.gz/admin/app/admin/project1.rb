ActiveAdmin.register_page "Project1" do
  menu priority: 6, label: -> { "snr" }

  content do
    panel "" do
      table_for [{id: 6, email: "pochi"},{id: 5, email: "test"},{id: 2, email: "kamiya"},{id: 1, email: "admin"}].each do
        column "date"
        column "player_id"
        column "sonota" do |v| raw("abcdef") end
      end
    end
  end
end

