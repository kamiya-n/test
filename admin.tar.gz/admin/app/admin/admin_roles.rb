ActiveAdmin.register AdminRole do
  menu priority: 3, label: -> { 'Roles' }

  permit_params :name

  index do
    column :id
    column :name
    column :created_at
    column :updated_at
    actions
  end

  filter :name

end
