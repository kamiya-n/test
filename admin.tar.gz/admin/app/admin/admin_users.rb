ActiveAdmin.register AdminUser do
  menu priority: 2, label: -> { 'Users' }

  config.per_page = 15 # 一覧ページのページングの件数

  permit_params :email, :password, :password_confirmation, admin_role_ids: []

  index do
    column :id
    column :admin_roles do |f|
      f.admin_roles.size > 0 ? f.admin_roles.map { |r| r.name }.join(", ") : ''
    end
    column :email
    column :current_sign_in_at
    column :sign_in_count
    column :created_at
    column :lots_of do |v| raw("abcdef") end
    actions


#    if !params[:q].blank?
#      if !params[:q][:admin_role_assigns_admin_role_id_eq].blank?
#        pp params[:q][:admin_role_assigns_admin_role_id_eq]
#      end
#    end
  end

  filter :admin_roles

  form do |f|
    f.inputs "Admin Details" do
      f.input :email
      f.input :password
      f.input :password_confirmation
      f.input :admin_roles
    end
    f.actions
  end

  # パスワードが空の状態で編集した場合はパスワード更新しないように（can't be blank エラーの防止）
  controller do
    def index
pp super
    end

    def update
      if params[:admin_user][:password].blank?
        params[:admin_user].delete("password")
        params[:admin_user].delete("password_confirmation")
      end
      super
    end
  end
end
