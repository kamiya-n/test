ActiveAdmin.register_page "Project3" do
  menu priority: 5, label: -> { 'mb' }

  content do
    render partial: 'admin/custom/index', locals: { var1: 'abc', var2: 'def' }
  end
end
