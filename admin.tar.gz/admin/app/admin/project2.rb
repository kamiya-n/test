ActiveAdmin.register_page "Project2" do
  menu priority: 4, label: -> { 'senpro' }

  content do
    render partial: 'admin/custom/index', locals: { var1: 'abc', var2: 'def' }
  end
end
