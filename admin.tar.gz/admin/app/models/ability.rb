class Ability
  include CanCan::Ability
  def initialize(user)
    can :manage, ActiveAdmin::Page, :name => 'Dashboard'

    user.admin_roles.each { |role|
      if admin? role.name
        can :manage, :all
      else
        cannot :manage, AdminUser
        cannot :manage, AdminRole        
        other to_camel role.name
     end
    }
  end


  private

  def admin? role
    role == 'admin' ? true : false
  end

  def other role
    can :read, ActiveAdmin::Page, :name => role
  end

  def to_camel(str)
    str.split("_").map{|w| w[0] = w[0].upcase; w}.join
  end
end
